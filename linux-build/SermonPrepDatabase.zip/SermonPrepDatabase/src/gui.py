'''
@author Jeremy G. Wilson

Copyright 2022 Jeremy G. Wilson

This file is a part of the Sermon Prep Database program (v.3.2.3)

Sermon Prep Database is free software: you can redistribute it and/or
modify it under the terms of the GNU General Public License (GNU GPL)
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

The Sermon Prep Database program includes Artifex Software's GhostScript,
licensed under the GNU Affero General Public License (GNU AGPL). See
https://www.ghostscript.com/licensing/index.html for more information.
'''
import os
import shutil
import sys
import threading
from datetime import datetime
from os.path import exists

from PyQt5.QtCore import Qt, QSize, QDate, QDateTime
from PyQt5.QtGui import QIcon, QFont, QKeyEvent
from PyQt5.QtWidgets import *

from Dialogs import yes_no_cancel_box, message_box
from MenuBar import MenuBar
from TopFrame import TopFrame


class GUI():
    spd = None
    win = None
    undo_stack = None
    changes = False
    font_family = None
    font_size = None
    
    def __init__(self, spd):
        self.spd = spd
        self.check_for_db()
        self.init_components()

    # check if the database file exists, and that the user_settings table exists. Prompt to create new if not.
    def check_for_db(self):
        if not exists(self.spd.db_loc):
            response = yes_no_cancel_box(
                'Database Not Found',
                'It looks like this is the first time you\'ve run Sermon Prep Database v3.2.3.\n'
                'Would you like to import an old database?',
                '#ffffff',
                'Import',
                'Create New'
            )

            if response == 0:
                from ConvertDatabase import ConvertDatabase
                ConvertDatabase(self.spd)
            elif response == 1:
                shutil.copy(self.spd.cwd + 'src/database_template.db', self.spd.db_loc)
                message_box('Database Created', 'A new database has been created.', '#ffffff')
            else:
                print('Cancel pressed')
                quit(0)

        self.spd.write_to_log('checkForDB completed')

    def init_components(self):
        self.spd.get_ids()
        self.spd.get_date_list()
        self.spd.get_scripture_list()
        self.spd.get_user_settings()
        self.spd.backup_db()

        self.accent_color = self.spd.user_settings[1]
        self.background_color = self.spd.user_settings[2]
        self.font_family = self.spd.user_settings[3]
        self.font_size = self.spd.user_settings[4]

        self.win = Win(self)
        self.win.setWindowIcon(QIcon(self.spd.cwd + 'resources/icon.png'))

        self.layout = QBoxLayout(QBoxLayout.TopToBottom)
        self.main_widget = QWidget()
        self.main_widget.setStyleSheet('background-color: white;')
        self.win.setCentralWidget(self.main_widget)
        self.main_widget.setLayout(self.layout)

        self.undo_stack = QUndoStack(self.main_widget)

        self.menu_bar = MenuBar(self.win, self, self.spd)
        self.top_frame = TopFrame(self.win, self, self.spd)
        self.layout.addWidget(self.top_frame)
        self.build_tabbed_frame()
        self.build_scripture_tab()
        self.build_exegesis_tab()
        self.build_outline_tab()
        self.build_research_tab()
        self.build_sermon_tab()
        self.set_style_sheets()

        self.win.show()
    
    def build_tabbed_frame(self):
        self.tabbed_frame = QTabWidget()
        self.tabbed_frame.setTabPosition(QTabWidget.West)
        self.tabbed_frame.setIconSize(QSize(24, 24))
        self.layout.addWidget(self.tabbed_frame)
        
    def build_scripture_tab(self):
        self.scripture_frame = QWidget()
        self.scripture_frame.setStyleSheet('background-color: ' + self.background_color)
        self.scripture_frame_layout = QGridLayout()
        self.scripture_frame_layout.setColumnMinimumWidth(1, 20)
        self.scripture_frame.setLayout(self.scripture_frame_layout)
        
        pericope_label = QLabel(self.spd.user_settings[5])
        self.scripture_frame_layout.addWidget(pericope_label, 0, 0)
        
        pericope_field = QLineEdit()
        pericope_field.textEdited.connect(self.changes_detected)
        self.scripture_frame_layout.addWidget(pericope_field, 1, 0)
        
        pericope_text_label = QLabel(self.spd.user_settings[6])
        self.scripture_frame_layout.addWidget(pericope_text_label, 2, 0)
        
        pericope_text_edit = QTextEdit()
        pericope_text_edit.textChanged.connect(self.changes_detected)
        pericope_text_edit.cursorPositionChanged.connect(lambda: self.set_style_buttons(pericope_text_edit))
        self.scripture_frame_layout.addWidget(pericope_text_edit, 3, 0)
        
        sermon_reference_label = QLabel(self.spd.user_settings[7])
        self.scripture_frame_layout.addWidget(sermon_reference_label, 0, 2)
        
        self.sermon_reference_field = QLineEdit()
        self.sermon_reference_field.textEdited.connect(self.reference_changes)
        self.scripture_frame_layout.addWidget(self.sermon_reference_field, 1, 2)
        
        sermon_text_label = QLabel(self.spd.user_settings[8])
        self.scripture_frame_layout.addWidget(sermon_text_label, 2, 2)
        
        self.sermon_text_edit = QTextEdit()
        self.sermon_text_edit.textChanged.connect(self.changes_detected)
        self.sermon_text_edit.cursorPositionChanged.connect(lambda: self.set_style_buttons(self.sermon_text_edit))
        self.scripture_frame_layout.addWidget(self.sermon_text_edit, 3, 2)
        
        self.tabbed_frame.addTab(self.scripture_frame, QIcon(self.spd.cwd + 'resources/scriptureIcon.png'), 'Scripture')
        
    def build_exegesis_tab(self):
        self.exegesis_frame = QWidget()
        self.exegesis_frame_layout = QGridLayout()
        self.exegesis_frame_layout.setColumnMinimumWidth(1, 20)
        self.exegesis_frame_layout.setColumnMinimumWidth(3, 20)
        self.exegesis_frame_layout.setColumnMinimumWidth(5, 20)
        self.exegesis_frame_layout.setRowMinimumHeight(2, 50)
        self.exegesis_frame_layout.setRowMinimumHeight(5, 50)
        self.exegesis_frame_layout.setRowStretch(8, 100)
        self.exegesis_frame.setLayout(self.exegesis_frame_layout)
        
        fcft_label = QLabel(self.spd.user_settings[9])
        self.exegesis_frame_layout.addWidget(fcft_label, 0, 0)
        
        fcft_text = QTextEdit()
        fcft_text.textChanged.connect(self.changes_detected)
        fcft_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(fcft_text))
        self.exegesis_frame_layout.addWidget(fcft_text, 1, 0)
        
        gat_label = QLabel(self.spd.user_settings[10])
        self.exegesis_frame_layout.addWidget(gat_label, 3, 0)
        
        gat_text = QTextEdit()
        gat_text.textChanged.connect(self.changes_detected)
        gat_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(gat_text))
        self.exegesis_frame_layout.addWidget(gat_text, 4, 0)
        
        cpt_label = QLabel(self.spd.user_settings[11])
        self.exegesis_frame_layout.addWidget(cpt_label, 6, 0)
        
        cpt_text = QTextEdit()
        cpt_text.textChanged.connect(self.changes_detected)
        cpt_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(cpt_text))
        self.exegesis_frame_layout.addWidget(cpt_text, 7, 0)
        
        pb_label = QLabel(self.spd.user_settings[12])
        self.exegesis_frame_layout.addWidget(pb_label, 3, 2)
        
        pb_text = QTextEdit()
        pb_text.textChanged.connect(self.changes_detected)
        pb_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(pb_text))
        self.exegesis_frame_layout.addWidget(pb_text, 4, 2)
        
        fcfs_label = QLabel(self.spd.user_settings[13])
        self.exegesis_frame_layout.addWidget(fcfs_label, 0, 4)
        
        fcfs_text = QTextEdit()
        fcfs_text.textChanged.connect(self.changes_detected)
        fcfs_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(fcfs_text))
        self.exegesis_frame_layout.addWidget(fcfs_text, 1, 4)
        
        gas_label = QLabel(self.spd.user_settings[14])
        self.exegesis_frame_layout.addWidget(gas_label, 3, 4)
        
        gas_text = QTextEdit()
        gas_text.textChanged.connect(self.changes_detected)
        gas_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(gas_text))
        self.exegesis_frame_layout.addWidget(gas_text, 4, 4)
        
        cps_label = QLabel(self.spd.user_settings[15])
        self.exegesis_frame_layout.addWidget(cps_label, 6, 4)
        
        cps_text = QTextEdit()
        cps_text.textChanged.connect(self.changes_detected)
        cps_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(cps_text))
        self.exegesis_frame_layout.addWidget(cps_text, 7, 4)

        text_box = QWidget()
        text_box.setObjectName('text_box')
        text_box.setMaximumWidth(300)
        text_layout = QVBoxLayout()
        text_box.setLayout(text_layout)
        text_title = QLabel()
        text_title.setObjectName('text_title')
        text_title.setStyleSheet('font-weight: bold; text-decoration: underline;')
        text_layout.addWidget(text_title)
        textedit = QTextEdit()
        textedit.setObjectName('text_edit')
        textedit.setStyleSheet('background-color: ' + self.background_color + '; border: 0;')
        textedit.setReadOnly(True)
        text_layout.addWidget(textedit)
        text_box.hide()
        self.exegesis_frame_layout.addWidget(text_box, 0, 6, 8, 1)
        
        self.tabbed_frame.addTab(self.exegesis_frame, QIcon(self.spd.cwd + 'resources/exegIcon.png'), 'Exegesis')
        
    def build_outline_tab(self):
        self.outline_frame = QWidget()
        self.outline_frame_layout = QGridLayout()
        self.outline_frame_layout.setColumnMinimumWidth(1, 20)
        self.outline_frame_layout.setColumnMinimumWidth(3, 20)
        self.outline_frame_layout.setColumnMinimumWidth(5, 20)
        self.outline_frame.setLayout(self.outline_frame_layout)
        
        scripture_outline_label = QLabel(self.spd.user_settings[16])
        self.outline_frame_layout.addWidget(scripture_outline_label, 0, 0)
        
        scripture_outline_text = QTextEdit()
        scripture_outline_text.textChanged.connect(self.changes_detected)
        scripture_outline_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(scripture_outline_text))
        self.outline_frame_layout.addWidget(scripture_outline_text, 1, 0)
        
        sermon_outline_label = QLabel(self.spd.user_settings[17])
        self.outline_frame_layout.addWidget(sermon_outline_label, 0, 2)
        
        sermon_outline_text = QTextEdit()
        sermon_outline_text.textChanged.connect(self.changes_detected)
        sermon_outline_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(sermon_outline_text))
        self.outline_frame_layout.addWidget(sermon_outline_text, 1, 2)
        
        illustration_label = QLabel(self.spd.user_settings[18])
        self.outline_frame_layout.addWidget(illustration_label, 0, 4)
        
        illustration_text = QTextEdit()
        illustration_text.textChanged.connect(self.changes_detected)
        illustration_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(illustration_text))
        self.outline_frame_layout.addWidget(illustration_text, 1, 4)

        text_box = QWidget()
        text_box.setObjectName('text_box')
        text_box.setMaximumWidth(300)
        text_layout = QVBoxLayout()
        text_box.setLayout(text_layout)
        text_title = QLabel()
        text_title.setObjectName('text_title')
        text_title.setStyleSheet('font-weight: bold; text-decoration: underline;')
        text_layout.addWidget(text_title)
        text_edit = QTextEdit()
        text_edit.setObjectName('text_edit')
        text_edit.setStyleSheet('background-color: ' + self.background_color + '; border: 0;')
        text_edit.setReadOnly(True)
        text_layout.addWidget(text_edit)
        text_box.hide()
        self.outline_frame_layout.addWidget(text_box, 0, 6, 5, 1)

        self.tabbed_frame.addTab(self.outline_frame, QIcon(self.spd.cwd + 'resources/outlineIcon.png'), 'Outlines')
        
    def build_research_tab(self):
        self.research_frame = QWidget()
        self.research_frame_layout = QGridLayout()
        self.research_frame.setLayout(self.research_frame_layout)
        self.research_frame_layout.setColumnMinimumWidth(1, 20)
        
        research_label = QLabel(self.spd.user_settings[19])
        self.research_frame_layout.addWidget(research_label, 0, 0)
        
        research_text = QTextEdit()
        research_text.textChanged.connect(self.changes_detected)
        research_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(research_text))
        self.research_frame_layout.addWidget(research_text, 1, 0)

        text_box = QWidget()
        text_box.setObjectName('text_box')
        text_box.setMaximumWidth(300)
        text_layout = QVBoxLayout()
        text_box.setLayout(text_layout)
        text_title = QLabel()
        text_title.setObjectName('text_title')
        text_title.setStyleSheet('font-weight: bold; text-decoration: underline;')
        text_layout.addWidget(text_title)
        text_edit = QTextEdit()
        text_edit.setObjectName('text_edit')
        text_edit.setStyleSheet('background-color: ' + self.background_color + '; border: 0;')
        text_edit.setReadOnly(True)
        text_layout.addWidget(text_edit)
        text_box.hide()
        self.research_frame_layout.addWidget(text_box, 0, 2, 2, 1)
        
        self.tabbed_frame.addTab(self.research_frame, QIcon(self.spd.cwd + 'resources/researchIcon.png'), 'Research')
        
    def build_sermon_tab(self):
        self.sermon_frame = QWidget()
        self.sermon_frame_layout = QGridLayout()
        self.sermon_frame.setLayout(self.sermon_frame_layout)
        self.sermon_frame_layout.setColumnMinimumWidth(2, 20)
        self.sermon_frame_layout.setColumnMinimumWidth(5, 20)
        self.sermon_frame_layout.setColumnMinimumWidth(8, 20)
        self.sermon_frame_layout.setRowMinimumHeight(2, 20)
        self.sermon_frame_layout.setRowMinimumHeight(5, 20)
        
        sermon_title_label = QLabel(self.spd.user_settings[20])
        self.sermon_frame_layout.addWidget(sermon_title_label, 0, 0, 1, 2)
        
        sermon_title_field = QLineEdit()
        sermon_title_field.textEdited.connect(self.changes_detected)
        self.sermon_frame_layout.addWidget(sermon_title_field, 1, 0, 1, 2)
        
        sermon_date_label = QLabel(self.spd.user_settings[21])
        self.sermon_frame_layout.addWidget(sermon_date_label, 0, 3, 1, 2)
        
        '''self.sermon_date_field = QLineEdit()
        self.sermon_date_field.textEdited.connect(self.date_changes)
        self.sermon_frame_layout.addWidget(self.sermon_date_field, 1, 3, 1, 2)'''

        self.sermon_date_edit = QDateEdit()
        self.sermon_date_edit.setCalendarPopup(True)
        self.sermon_date_edit.setMinimumHeight(30)
        self.sermon_date_edit.dateChanged.connect(self.date_changes)
        self.sermon_frame_layout.addWidget(self.sermon_date_edit, 1, 3, 1, 2)
        
        sermon_location_label = QLabel(self.spd.user_settings[22])
        self.sermon_frame_layout.addWidget(sermon_location_label, 0, 6, 1, 2)
        
        sermon_location_field = QLineEdit()
        sermon_location_field.textEdited.connect(self.changes_detected)
        self.sermon_frame_layout.addWidget(sermon_location_field, 1, 6, 1, 2)
        
        ctw_label = QLabel(self.spd.user_settings[23])
        self.sermon_frame_layout.addWidget(ctw_label, 3, 0, 1, 2)
        
        ctw_field = QLineEdit()
        ctw_field.textEdited.connect(self.changes_detected)
        self.sermon_frame_layout.addWidget(ctw_field, 4, 0, 1, 2)
        
        hr_label = QLabel(self.spd.user_settings[24])
        self.sermon_frame_layout.addWidget(hr_label, 3, 6, 1, 2)
        
        hr_field = QLineEdit()
        hr_field.textEdited.connect(self.changes_detected)
        self.sermon_frame_layout.addWidget(hr_field, 4, 6, 1, 2)
        
        sermon_label = QLabel(self.spd.user_settings[25])
        self.sermon_frame_layout.addWidget(sermon_label, 6, 0)
        
        sermon_text = QTextEdit()
        sermon_text.textChanged.connect(self.changes_detected)
        sermon_text.cursorPositionChanged.connect(lambda: self.set_style_buttons(sermon_text))
        self.sermon_frame_layout.addWidget(sermon_text, 7, 0, 1, 8)

        text_box = QWidget()
        text_box.setObjectName('text_box')
        text_box.setMaximumWidth(300)
        text_layout = QVBoxLayout()
        text_box.setLayout(text_layout)
        text_title = QLabel()
        text_title.setObjectName('text_title')
        text_title.setStyleSheet('font-weight: bold; text-decoration: underline;')
        text_layout.addWidget(text_title)
        text_edit = QTextEdit()
        text_edit.setObjectName('text_edit')
        text_edit.setStyleSheet('background-color: ' + self.background_color + '; border: 0;')
        text_edit.setReadOnly(True)
        text_box.hide()
        text_layout.addWidget(text_edit)
        self.sermon_frame_layout.addWidget(text_box, 0, 9, 8, 1)
        
        self.tabbed_frame.addTab(self.sermon_frame, QIcon(self.spd.cwd + 'resources/sermonIcon.png'), 'Sermon')

    def set_style_sheets(self):
        self.tabbed_frame.setStyleSheet('''
            QTabWidget::pane {
                border: 50px solid ''' + self.background_color + ''';}
            QTabBar::tab {
                background-color: ''' + self.accent_color + ''';
                color: white;
                font-family: "''' + self.font_family + '''";
                font-size: ''' + str(self.font_size) + '''pt;
                font-weight: bold;
                width: 40px;
                height: 120px;
                padding: 10px;
                margin-bottom: 5px;}
            QTabBar::tab:selected {
                background-color: ''' + self.background_color + ''';
                color: black;
                font-family: "''' + self.font_family + '''";
                font-size: 20px;
                font-weight: bold;
                width: 50px;}
            ''')

        standard_style_sheet = ('''
            QWidget {
                background-color: ''' + self.background_color + ''';}
            QLabel {
                font-family: "''' + self.font_family + '''";
                font-size: ''' + str(self.font_size) + '''pt;}
            QLineEdit {
                background-color: white;
                font-family: "''' + self.font_family + '''";
                font-size: ''' + str(self.font_size) + '''pt;
                padding: 3px;
                border: 1px solid ''' + self.accent_color + ''';}
            QTextEdit {
                background-color: white;
                font-family: "''' + self.font_family + '''";
                font-size: ''' + str(self.font_size) + '''pt;
                padding: 3px;
                border: 1px solid ''' + self.accent_color + ''';}
            ''')

        self.scripture_frame.setStyleSheet(standard_style_sheet)
        self.exegesis_frame.setStyleSheet(standard_style_sheet)
        self.outline_frame.setStyleSheet(standard_style_sheet)
        self.research_frame.setStyleSheet(standard_style_sheet)
        self.sermon_frame.setStyleSheet(standard_style_sheet)

    def set_style_buttons(self, component):
        cursor = component.textCursor()
        font = cursor.charFormat().font()
        if font.weight() == QFont.Normal:
            self.top_frame.bold_button.setChecked(False)
        else:
            self.top_frame.bold_button.setChecked(True)
        if font.italic():
            self.top_frame.italic_button.setChecked(True)
        else:
            self.top_frame.italic_button.setChecked(False)
        if font.underline():
            self.top_frame.underline_button.setChecked(True)
        else:
            self.top_frame.underline_button.setChecked(False)

        text_list = cursor.currentList()
        if text_list:
            self.top_frame.bullet_button.setChecked(True)
        else:
            self.top_frame.bullet_button.setChecked(False)
        
    def fill_values(self, record):
        index = 1;
        self.win.setWindowTitle('Sermon Prep Database - ' + str(record[0][17]) + ' - ' + str(record[0][3]))
        for i in range(self.scripture_frame_layout.count()):
            component = self.scripture_frame_layout.itemAt(i).widget()
            if isinstance(component, QLineEdit):
                if record[0][index]:
                    component.setText(str(record[0][index].replace('&quot', '"')))
                else:
                    component.clear()
                index += 1
            elif isinstance(component, QTextEdit):
                if record[0][index]:
                    component.setMarkdown(record[0][index].replace('&quot', '"'))
                else:
                    component.clear()
                index += 1
        for i in range(self.exegesis_frame_layout.count()):
            component = self.exegesis_frame_layout.itemAt(i).widget()
            if isinstance(component, QTextEdit) and not component.objectName() == 'text_box':
                if record[0][index]:
                    component.setMarkdown(record[0][index].replace('&quot', '"'))
                else:
                    component.clear()
                index += 1
        for i in range(self.outline_frame_layout.count()):
            component = self.outline_frame_layout.itemAt(i).widget()
            if isinstance(component, QTextEdit) and not component.objectName() == 'text_box':
                if record[0][index]:
                    component.setMarkdown(record[0][index].replace('&quot', '"'))
                else:
                    component.clear()
                index += 1
        for i in range(self.research_frame_layout.count()):
            component = self.research_frame_layout.itemAt(i).widget()
            if isinstance(component, QTextEdit):
                if record[0][index]:
                    text = self.spd.reformat_string_for_load(record[0][index])
                    component.setMarkdown(text)
                else:
                    component.clear()
                index += 1
        for i in range(self.sermon_frame_layout.count()):
            component = self.sermon_frame_layout.itemAt(i).widget()
            if isinstance(component, QLineEdit) or isinstance(component, QDateEdit):
                if isinstance(component, QLineEdit):
                    if record[0][index]:
                        component.setText(record[0][index].replace('&quot', '"'))
                    else:
                        component.clear()
                else:
                    date = record[0][index]
                    unusable_date = False
                    if '/' in date:
                        date_split = date.split('/')
                    elif '\\' in date:
                        date_split = date.split('\\')
                    elif '-' in date:
                        date_split = date.split('-')
                    else:
                        unusable_date = True
                    if not unusable_date:
                        if int(date_split[0]) > 31:
                            component.setDate(QDate(int(date_split[0]), int(date_split[1]), int(date_split[2])))
                        elif date_split[2] > 31:
                            component.setDate(QDate(int(date_split[2]), int(date_split[0]), int(date_split[1])))
                    else:
                        self.spd.write_to_log('unusable date in record #' + str(record[0][0]))
                        component.setDate(QDateTime.currentDateTime().date())
                index += 1
            if isinstance(component, QTextEdit) and not component.objectName() == 'text_box':
                if record[0][index]:
                    component.setMarkdown(record[0][index].replace('&quot', '"'))
                else:
                    component.clear()
                index += 1

        num_tabs = self.tabbed_frame.count()
        for i in range(num_tabs):
            if i > 0:
                frame = self.tabbed_frame.widget(i)
                widget = frame.findChild(QTextEdit, 'text_box')
                if widget:
                    if record[0][4]:
                        widget.setMarkdown(record[0][4].replace('&quot', '"'))
                    else:
                        widget.clear()
        self.top_frame.id_label.setText('ID: ' + str(record[0][0]))
        self.changes = False

    def changes_detected(self):
        self.changes = True

    def reference_changes(self):
        self.top_frame.references_cb.setItemText(self.top_frame.references_cb.currentIndex(), self.sermon_reference_field.text())
        self.win.setWindowTitle('Sermon Prep Database - ' + self.sermon_date_field.text() + ' - ' + self.sermon_reference_field.text())
        self.changes = True

    def date_changes(self):
        #self.top_frame.dates_cb.setItemText(self.top_frame.dates_cb.currentIndex(), self.sermon_date_field.text())
        self.top_frame.dates_cb.setItemText(self.top_frame.dates_cb.currentIndex(), self.sermon_date_edit.text())
        #self.win.setWindowTitle('Sermon Prep Database - ' + self.sermon_date_field.text() + ' - ' + self.sermon_reference_field.text())
        self.win.setWindowTitle(
            'Sermon Prep Database - ' + self.sermon_date_edit.text() + ' - ' + self.sermon_reference_field.text())
        self.changes = True

    def do_exit(self):
        goon = True
        if self.changes:
            goon = self.spd.ask_save()
        if goon:
            sys.exit(0)

class Win(QMainWindow):
    from PyQt5.QtGui import QCloseEvent

    def __init__(self, gui):
        QMainWindow.__init__(self)
        self.gui = gui
        self.setWindowTitle('Sermon Prep Database')
        self.setStyleSheet('background-color: white')
        self.resize(1000, 800)
        self.move(50, 50)

    def closeEvent(self, event:QCloseEvent) -> None:
        event.ignore()
        self.gui.do_exit()

    def keyPressEvent(self, event:QKeyEvent):
        if (event.modifiers() & Qt.ControlModifier) and (event.modifiers() & Qt.ShiftModifier) and event.key() == Qt.Key_B:
            self.gui.top_frame.set_bullet()
            self.gui.top_frame.bullet_button.blockSignals(True)
            if self.gui.top_frame.bullet_button.isChecked():
                self.gui.top_frame.bullet_button.setChecked(False)
            else:
                self.gui.top_frame.bullet_button.setChecked(True)
            self.gui.top_frame.bold_button.blockSignals(False)
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_B:
            self.gui.top_frame.set_bold()
            self.gui.top_frame.bold_button.blockSignals(True)
            if self.gui.top_frame.bold_button.isChecked():
                self.gui.top_frame.bold_button.setChecked(False)
            else:
                self.gui.top_frame.bold_button.setChecked(True)
            self.gui.top_frame.bold_button.blockSignals(False)
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_I:
            self.gui.top_frame.set_italic()
            self.gui.top_frame.italic_button.blockSignals(True)
            if self.gui.top_frame.italic_button.isChecked():
                self.gui.top_frame.italic_button.setChecked(False)
            else:
                self.gui.top_frame.italic_button.setChecked(True)
            self.gui.top_frame.italic_button.blockSignals(False)
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_U:
            self.gui.top_frame.set_underline()
            self.gui.top_frame.underline_button.blockSignals(True)
            if self.gui.top_frame.underline_button.isChecked():
                self.gui.top_frame.underline_button.setChecked(False)
            else:
                self.gui.top_frame.underline_button.setChecked(True)
            self.gui.top_frame.underline_button.blockSignals(False)
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_S:
            self.gui.spd.save_rec()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_P:
            self.gui.menu_bar.print_rec()
        elif event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_Q:
            self.gui.do_exit()
        event.accept()
